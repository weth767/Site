A Pen created at CodePen.io. You can find this one at http://codepen.io/chrisdothtml/pen/azPYqq.

 A few cool social buttons with smooth animations. Inspired by https://dribbble.com/shots/1983177-Retina

To see how this was made, check this blog post out! http://deacy.io/blog/stylish-social-media-buttons/
/*

also forked with CrAZy flip
http://codepen.io/pouretrebelle/pen/xHuit

*/

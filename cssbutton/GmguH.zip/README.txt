A Pen created at CodePen.io. You can find this one at http://codepen.io/pouretrebelle/pen/GmguH.

 Messing around with 3d transforms and delayed transitions. Colours from http://colour.charlottedann.com/
and icons from http://symbolset.com/
A Pen created at CodePen.io. You can find this one at http://codepen.io/colewaldrip/pen/bdZVGd.

 I saw an effect similar to this somewhere, so I just wanted to play around with the idea! Hover over the buttons to see the colors invert, the icon rotate, and the border grow from within the button.
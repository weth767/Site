A Pen created at CodePen.io. You can find this one at http://codepen.io/pedox/pen/DimhI.

 Other version Windows 8 Metro UI Like @ashx89 for icon i use FontAwesome, i can't find IE logo and any stuff logo in FontAwesome make bad :p